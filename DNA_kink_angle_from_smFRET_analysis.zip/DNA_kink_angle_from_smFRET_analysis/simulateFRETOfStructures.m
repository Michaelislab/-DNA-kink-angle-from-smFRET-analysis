%% Input Parameters

Riso = 7.0; % isotropic F�rster radius (nm)
trajN = 5000; % number of donor excitations
seidelAss = false; % dynamic and unrestricted averaging in orientation and static position averaging 
randAx = true; % random cone axes for donor and acceptor

% acceptor
kRA = 1/0.70; % rate of rotation = 1 / rotational correlation time (ns)
depA = 0.126/0.4;%0.15/0.4; % depolarization factor = rinf / 0.4

% donor
kD = 1/3.53; % rate of depopulation of excited donor in absence of acceptor = 1 / fluorescence lifetime of donor in absence of acceptor (ns)
kRD = 1/1.34; % rate of rotation = 1 / rotational correlation time (ns)
depD = 0.042/0.4; % depolarization factor = rinf / 0.4

%%

addpath('./helperCode');


%% Load data

[filename, pathname] = uiiofile('PDBimport','Load','*.mat','Load Priors');
if isequal(filename,0) || isequal(pathname,0)
    % User selected Cancel
    return
else
    load([pathname, filename]);
end

numModels = length(priors);

meanFRETeff = zeros(1,numModels);
emissionBool = zeros(trajN,numModels);
photonTime = zeros(trajN,numModels);

%% Simulation

tic
parfor modelInd = 1:numModels
    
    [meanFRETeff(modelInd), emissionBool(:,modelInd),photonTime(:,modelInd)] = simulateFRETeff(seidelAss,randAx,...
        priors{modelInd}{1}, priors{modelInd}{3}, priors{modelInd}{2}, priors{modelInd}{4},...
        trajN, kD, Riso, depD, kRD, depA, kRA);
    
    modelInd
    
end

toc

plot(sort(meanFRETeff))

[file,path] = uiputfile('*.mat');
if isequal(file,0) || isequal(path,0)
    disp('User clicked Cancel.')
else
    disp(['User selected ',fullfile(path,file),...
        ' and then clicked Save.'])
    save([path,filesep,file],'meanFRETeff','emissionBool','photonTime')
end



%% test
clear stD
k = 1;

for i = divisors(trajN)
    
   stD(k) = std(sum(reshape(processBool(1:100*i),i,[])./i,1)); 
   k = k + 1;
   
end

plot(stD)







