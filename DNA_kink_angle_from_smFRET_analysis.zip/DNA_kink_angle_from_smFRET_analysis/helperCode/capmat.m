function [ x, varargout ] = capmat( x, varargin )
%CAPMAT cap n-dimensional matrix with zeros
%
% FUNCTION CALLING:
%   [cx] = capmat( x )
%   [cx, ca] = capmat( x, a )
%
% INPUT ARGUMENTS:
%   x       N-dimensional matrix
%   a		axes, cell array of length N, the i-th element being a vector of size(x,i)
%
% OUTPUT ARGUMENTS:
%   cx      capped matrix
%   ca	capped axes
%
%--------------------------------------------------------------------------
% CHANGES LOG:
%   2009-03-20  first version running [Adam]
%   2009-05-14  modified for logical matrices [Moritz Haag]
%   2010-01-25  modified for degenerate matrices [Adam]
%--------------------------------------------------------------------------

% check input
switch nargin
    case 1
		if (nargout ~= 1)
		  error('wrong number of output arguments');
		end
		a = {};	% no axes
    case 2
		if (nargout ~= 2)
		  error('wrong number of output arguments');
		end
		a = varargin{1};	% set axes
		varargout = {};	% initialize output
    otherwise
        error('wrong number of input arguments');
end

% get dimensionality of matrix
if ~isempty(a)
    N = length(a); % dimension
    d = ones(1, N); % preallocation
    dd = size(x); % just for length, why not N?
    d(1:length(dd)) = dd;
else
    d = size(x);
    N = length(d);
end

for i=1:N
	if (d(1) > 1)	% if there is more than 1 element in i-th dimension
		if(islogical(x))
            x = [false([1,d(2:end)]);x;false([1,d(2:end)])];
        else
            x = [zeros([1,d(2:end)]);x;zeros([1,d(2:end)])];
        end
        d(1) = d(1)+2;
		if ~isempty(a)		% if there are axes
			if (size(a{1},1) < size(a{1},2))
				resh = true;
				a(1) = {a{1}'};
			else
				resh = false;
			end
			a(1) = {[(2*a{1}(1)-a{1}(2));a{1};(2*a{1}(end)-a{1}(end-1))]};
			if resh
				a(1) = {a{1}'};
			end
		end
	end
	
	% rotate size vector
	d = [d(2:N),d(1)];
	% rotate matrix
	x = permute(x, [(2:N),1]);
	if ~isempty(a)
			if (size(a,1) < size(a,2))
				a = [a(1,2:N),a(1,1)];
			else
				a = [a(2:N,1);a(1,1)];
			end
	end
end

if ~isempty(a)
	varargout = {a};
end

end
