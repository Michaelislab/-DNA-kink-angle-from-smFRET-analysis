
tic

%% changing data

trajN = 10^3;

%% t-9
depA = 0;%0.201/0.4;
kRA = 1/0.5152;
%% nt+7
expInd = 1;
E = 0.66;
depD = 0.1745/0.4;
Riso = 7.19;
kD = 1/2.6763;
kRD = 1/1.0989;
%% nt+12
% expInd = 2;
% E = 0.43;
% depD = 0.1289/0.4;
% Riso = 7.34;
% kD = 1/2.8701;
% kRD = 1/1.2363;
%% nt-18
% expInd = 3;
% E = 0.89;
% depD = 0.2500/0.4;
% Riso = 7.26;
% kD = 1/2.8700;
% kRD = 1/1.3067;
%% nt-30
% expInd = 4;
% E = 0.46;
% depD = 0.1433/0.4;
% Riso = 7.17;
% kD = 1/2.6267;
% kRD = 1/1.1967;
%

%% Rotation Parameters

psi = @(dep) acos(sqrt(2.*sqrt(dep) + 0.25) - 0.5);

psiD =  psi(depD);
psiA =  psi(depA);

cPsiD = cos(psiD);
cPsiA = cos(psiA);

B = @(cPsi) -cPsi.^2.*(1+cPsi).^2 .* (log((1+cPsi)./2) + (1 - cPsi)./2)./ (2.*(1 - cPsi)) + (1-cPsi).*(6+8.*cPsi-cPsi.^2-12.*cPsi.^3-7.*cPsi.^4)./24;

DRotD = B(cPsiD) * kRD / (1 - depD); % rad^2/ns
DRotA = B(cPsiA) * kRA / (1 - depA); % rad^2/ns

%% translation Parameters

DTransD = 0.11; %0.11; % nm^2/ns
DTransA = 0.11; %0.11; % nm^2/ns

posD = zeros(3,trajN);
posA = zeros(3,trajN);

%% shift

epsilon = 0.01;

steps = [-2.5:epsilon:1.5];%zeros(1,100);%

varyRiso = repmat(Riso,1,length(steps)); %Riso .* (1 + 0.04 .* randn(1,length(steps)));

dynRotStatPosE = zeros(1,length(steps));

statRotStatPosE = dynRotStatPosE;

dynRotDynPosE = dynRotStatPosE;

statRotDynPosE = dynRotStatPosE;

simE = dynRotStatPosE;

randAxSimE = simE;

parfor k = 1:length(steps)
    
    %% Positions
    capsN = 6;
    
    histD = capmat(densityD);
    histA = capmat(densityA);
    
    for i = 1:capsN
        histD = capmat(histD);
        histA = capmat(histA);
    end
    
    axesMinD = ([axesD{1}(1);axesD{2}(1);axesD{3}(1)] - repmat(capsN,3,1))/10 - 0.05; % shift by 0.5 A since boxes have edge length 1 A
    axesMinA = ([axesA{1}(1);axesA{2}(1);axesA{3}(1)] - repmat(capsN,3,1))/10 - 0.05;
    
    posD = zeros(3,trajN);
    posA = zeros(3,trajN);
    
    maxIndD = size(histD)';
    maxIndA = size(histA)';
    
    a = 0;
    
    for trajInd = 1:trajN
        
        randIndD = ceil(rand(3,1) .* maxIndD);
        while ~histD(randIndD(1),randIndD(2),randIndD(3))
            randIndD = ceil(rand(3,1) .* maxIndD);
        end
        posD(:,trajInd) = randIndD + 10 .* axesMinD - rand(3,1);
        
        % test
        tempPosD = posD(:,trajInd)./10;
        histIndD = ceil(10.*(tempPosD - axesMinD));
        
        if ~histD(histIndD(1),histIndD(2),histIndD(3))
            a = a + 1;
        end
        
        randIndA = ceil(rand(3,1) .* maxIndA);
        while ~histA(randIndA(1),randIndA(2),randIndA(3))
            randIndA = ceil(rand(3,1) .* maxIndA);
        end
        posA(:,trajInd) = randIndA + 10 .* axesMinA - rand(3,1);
        
        % test
        tempPosA = posA(:,trajInd)/10;
        histIndA = ceil(10.*(tempPosA - axesMinA));
        
        if ~histA(histIndA(1),histIndA(2),histIndA(3))
            a = a + 1;
        end
    end
    if a > 0
        error('outside Position Prior')
    end
    
    posD = posD ./ 10;
    posA = posA ./ 10;
    
    
    %% Orientations
    %% restricted Oris
    % axes
    [coeffD,scoreD,latentD] = pca(posD');
    [coeffA,scoreA,latentA] = pca(posA');
    
    [~,indMaxLatentD] = max(latentD);
    [~,indMaxLatentA] = max(latentA);
    
    axD = coeffD(:,indMaxLatentD);
    axD = axD ./ norm(axD);
    axA = coeffA(:,indMaxLatentA);
    axA = axA ./ norm(axA);
    
    % random angles from axis away
    randPsiD = repmat(acos((1-cPsiD).*rand(1,trajN)+ cPsiD),3,1);
    randPsiA = repmat(acos((1-cPsiA).*rand(1,trajN)+ cPsiA),3,1);
    
    % rotation angle around axis2
    randPhiD = repmat(2 .* pi .* rand(1,trajN),3,1);
    randPhiA = repmat(2 .* pi .* rand(1,trajN),3,1);
    
    % random ori's in cones with average axes ax's
    
    kernelD = null(axD'); % axis orthogonal plane vectors
    kernelA = null(axA'); % axis orthogonal plane vectors
    
    oriD = sin(randPsiD) .* (cos(randPhiD) .* ...
        repmat(kernelD(:,1),1,trajN) + sin(randPhiD) .* repmat(kernelD(:,2),1,trajN)) ...
        + cos(randPsiD) .* repmat(axD,1,trajN);
    
    oriA = sin(randPsiA) .* (cos(randPhiA) .* ...
        repmat(kernelA(:,1),1,trajN) + sin(randPhiA) .* repmat(kernelA(:,2),1,trajN)) ...
        + cos(randPsiA) .* repmat(axA,1,trajN);
    
    %% random ori's in cones with average axes randomAx's
    
    randAxD = rand(3,1);
    randAxD = randAxD ./ norm(randAxD);
    randAxA = rand(3,1);
    randAxA = randAxA ./ norm(randAxA);
    
    % random angles from axis away
    randPsiD = repmat(acos((1-cPsiD).*rand(1,trajN)+ cPsiD),3,1);
    randPsiA = repmat(acos((1-cPsiA).*rand(1,trajN)+ cPsiA),3,1);
    
    % rotation angle around axis2
    randPhiD = repmat(2 .* pi .* rand(1,trajN),3,1);
    randPhiA = repmat(2 .* pi .* rand(1,trajN),3,1);
    
    kernelD = null(randAxD'); % axis orthogonal plane vectors
    kernelA = null(randAxA'); % axis orthogonal plane vectors
    
    randOriD = sin(randPsiD) .* (cos(randPhiD) .* ...
        repmat(kernelD(:,1),1,trajN) + sin(randPhiD) .* repmat(kernelD(:,2),1,trajN)) ...
        + cos(randPsiD) .* repmat(randAxD,1,trajN);
    
    randOriA = sin(randPsiA) .* (cos(randPhiA) .* ...
        repmat(kernelA(:,1),1,trajN) + sin(randPhiA) .* repmat(kernelA(:,2),1,trajN)) ...
        + cos(randPsiA) .* repmat(randAxA,1,trajN);
    
    %% unrestricted Oris
    
    % unrestricted
    
    % random angles from axis away
    randPsiD = repmat(acos((1-0).*rand(1,trajN)+ 0),3,1);
    randPsiA = repmat(acos((1-0).*rand(1,trajN)+ 0),3,1);
    
    % rotation angle around axis2
    randPhiD = repmat(2 .* pi .* rand(1,trajN),3,1);
    randPhiA = repmat(2 .* pi .* rand(1,trajN),3,1);
    
    % random ori's in cones with average axes ax's
    
    kernelD = null(axD'); % axis orthogonal plane vectors
    kernelA = null(axA'); % axis orthogonal plane vectors
    
    unrestOriD = sin(randPsiD) .* (cos(randPhiD) .* ...
        repmat(kernelD(:,1),1,trajN) + sin(randPhiD) .* repmat(kernelD(:,2),1,trajN)) ...
        + cos(randPsiD) .* repmat(axD,1,trajN);
    
    unrestOriA = sin(randPsiA) .* (cos(randPhiA) .* ...
        repmat(kernelA(:,1),1,trajN) + sin(randPhiA) .* repmat(kernelA(:,2),1,trajN)) ...
        + cos(randPsiA) .* repmat(axA,1,trajN);
    
    
    %% Simulation Parameters
    
    radiusD = (3*sum(sum(sum(histD)))/(4*pi)).^(1/3)/10;
    radiusSqD = radiusD^2;
    
    radiusA = (3*sum(sum(sum(histA)))/(4*pi)).^(1/3)/10;
    radiusSqA = radiusA^2;
    
    minTransTime = min([radiusD^2/(6*DTransD),radiusA^2/(6*DTransA)]);
    
    minRotTime = min([psiD^2/(6*DRotD),psiA^2/(6*DRotA)]);
    
    meanDist = norm(mean(posD,2) - mean(posA,2));
    
    meanKT = kD * (Riso/meanDist)^6;
    
    h = max(10^(-3),min([minTransTime,minRotTime,1/kD,1/meanKT]) / 100);
    
    cTransD = sqrt(6*DTransD*h);
    cTransA = sqrt(6*DTransA*h);
    
    cRotD = sqrt(2*DRotD*h);
    cRotA = sqrt(2*DRotA*h);
    
    %% FRET efficiencies
       
    localPosA = reshape(posA,3,trajN) + repmat([0;0;steps(k)],1,trajN);
    
    simE(k) = simFRETeffShift(posD,localPosA,oriD,oriA,steps(k),trajN,h,kD,varyRiso(k),cTransD,cTransA,cRotD,cRotA,cPsiD,cPsiA,histD,histA,axesMinD,axesMinA,axD,axA);
    
    randAxSimE(k) = simFRETeffShift(posD,localPosA,randOriD,randOriA,steps(k),trajN,h,kD,varyRiso(k),cTransD,cTransA,cRotD,cRotA,cPsiD,cPsiA,histD,histA,axesMinD,axesMinA,randAxD,randAxA);
    
    % Limits
    normR = posD-localPosA;
    
    D6 = (varyRiso(k).^2./sum(normR.^2,1)).^3;
    
    dynRotStatPosE(k) = mean(1 ./ (1+D6.^(-1)));%sum((1 ./ (1+D6.^(-1))) > rand(1,trajN))/trajN;%
    
    normR = normR ./ repmat(sqrt(sum(normR.^2,1)),3,1);
    
    kappaSq = (sum(unrestOriD.*unrestOriA,1) - 3 .* sum(normR.*unrestOriD,1) .* sum(normR.*unrestOriA,1)).^2;
    
    kT = kD .* 3/2 .* kappaSq .* D6;
    
    statRotStatPosE(k) = mean(1 ./ (1+kD./kT));
    
    dynRotDynPosE(k) = 1 ./ (1+kD./mean(kT));
    
    kT = kD .* 3/2 .* kappaSq .* mean(D6);
    
    statRotDynPosE(k) = mean(1 ./ (1+kD./kT));
    
end

%% variance check

% combinedData = [mean(randAxSimE),mean(simE),mean(dynRotStatPosE),mean(statRotStatPosE),mean(dynRotDynPosE),mean(statRotDynPosE);...
%     std(randAxSimE),std(simE),std(dynRotStatPosE),std(statRotStatPosE),std(dynRotDynPosE),std(statRotDynPosE)]
% 
% figure
% hist([statRotStatPosE;dynRotDynPosE;statRotDynPosE;simE;randAxSimE]',0:0.01:1)


%% Shift

epsilon = .01;

steps = [-2.5:epsilon:1.5];%zeros(1,100);% %zeros(1,100);%[-3:epsilon:3];%[-0.6:epsilon:0.6];%

steps = steps * 10;

coeff = zeros(5,4);

polFun = @(steps,coeff) coeff(1).*steps.^3 + coeff(2).*steps.^2 + coeff(3).*steps + coeff(4);

expFRETeff = [0.66,0.43,0.89,0.46];

figure
plot(steps,dynRotStatPosE)
hold on
coeff(1,:) = polyfit(steps,dynRotStatPosE,3);
plot(steps,polFun(steps,coeff(1,:)))

% figure
plot(steps,statRotStatPosE,'y')
hold on
coeff(2,:) = polyfit(steps,statRotStatPosE,3);
plot(steps,polFun(steps,coeff(2,:)),'y')

plot(steps,dynRotDynPosE,'g')
hold on
coeff(3,:) = polyfit(steps,dynRotDynPosE,3);
plot(steps,polFun(steps,coeff(3,:)),'g')

% figure
plot(steps,statRotDynPosE,'k')
hold on
coeff(4,:) = polyfit(steps,statRotDynPosE,3);
plot(steps,polFun(steps,coeff(4,:)),'k')

% figure
plot(steps,simE,'r')
hold on
coeff(5,:) = polyfit(steps,simE,3);
plot(steps,polFun(steps,coeff(5,:)),'r')

plot([steps(1),steps(end)],[expFRETeff(expInd),expFRETeff(expInd)],'k')

figure
hold on
steps = [-3:0.01:3]*10;%

distShift = zeros(1,5);

for i = 1:5
    
    distShift(i) = fminbnd(@(steps)(polFun(steps,coeff(i,:))-expFRETeff(expInd)).^2,-40,40);
    
    plot(steps,(polFun(steps,coeff(i,:))-expFRETeff(expInd)).^2,'r')
    
end

toc