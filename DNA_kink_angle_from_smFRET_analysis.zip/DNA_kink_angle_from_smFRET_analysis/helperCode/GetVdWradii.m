function [ VdWradii ] = GetVdWradii( atomNames )
%GETVDWRADII returns the Van der Waals radii of the atoms in the cell array atomNames.
%
% The 'mean van der Waals radii for volume caluclations involving
% anisometric atoms' from Table I in A. Bondii, J. Phys. Chem. 1964, Vol 68
% pp.441-451 is used.
%
% input arguments:
%   atomNames   cell array of atom names read from a PDB file
% output arguments:
%   VdWradii    Van der Waals radii of the corresponding atoms, vector of
%               length length(atomNames)
%
% changes log:
%   2008-02-22  documentation written [Adam Muschielok]

% preallocate atom names
VdWradii = zeros(length(atomNames),1);

for i=1:length(atomNames)
    switch atomNames{i}(1)
        case 'C'    % carbon
            VdWradii(i) = 1.70;
        case 'N'    % nitrogen
            VdWradii(i) = 1.55;
        case 'H'    % hydrogen
            VdWradii(i) = 1.20;
        case 'O'    % oxygen
            VdWradii(i) = 1.52;
        case 'S'    % sulfur
            VdWradii(i) = 1.80;
        case 'P'    % phosphor
            VdWradii(i) = 1.80;
        otherwise
%            VdWradii(i) = -1;   % undefined VdW radius!
            VdWradii(i) = 0;   % undefined VdW radius!
       
    end
end
