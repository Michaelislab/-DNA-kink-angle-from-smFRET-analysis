function [ density ] = SkeletonizeDensity( density, axes, skelDist )
%SKELETONIZEDENSITY skeletonize 3D binary density

density = logical(density);

% coordinate system
[X, Y, Z] = ndgrid(axes{:});

% calculate expanded density
dd = density;
dd(1:end-1,:,:) = dd(1:end-1,:,:) | density(2:end,:,:);
dd(2:end,:,:)   = dd(2:end,:,:) | density(1:end-1,:,:);
dd(:,1:end-1,:) = dd(:,1:end-1,:) | density(:,2:end,:);
dd(:,2:end,:)   = dd(:,2:end,:) | density(:,1:end-1,:);
dd(:,:,1:end-1) = dd(:,:,1:end-1) | density(:,:,2:end);
dd(:,:,2:end)   = dd(:,:,2:end) | density(:,:,1:end-1);

% find 'outside'
stpt = false(size(X));  % initialize start points for (infinite) chain
stpt(1,:,:) = true;     stpt(end,:,:) = true;
stpt(:,1,:) = true;     stpt(:,end,:) = true;
stpt(:,:,1) = true;     stpt(:,:,end) = true;
stpt = find(stpt);
od = FloppyChainPrior( ~density, axes{1}, axes{2}, axes{3}, stpt, realmax);
dd = dd & od;   % interface voxels

% find interface points
intPts(:,1) = X(dd);
intPts(:,2) = Y(dd);
intPts(:,3) = Z(dd);
clear X Y Z dd

% use VanDerWaalsPrior.m to skeletonize map
dummypdb.positions = intPts;
dummypdb.names = num2cell(char(zeros(size(intPts,1),1)));
dummypdb.Bfactors = zeros(size(intPts,1),1);

density = density & VanDerWaalsPrior( dummypdb, axes{1}, axes{2}, axes{3}, skelDist );

% for i=1:steps
%     density(1:end-1,:,:) = density(1:end-1,:,:) & density(2:end,:,:);
%     density(2:end,:,:)   = density(2:end,:,:) & density(1:end-1,:,:);
%     density(:,1:end-1,:) = density(:,1:end-1,:) & density(:,2:end,:);
%     density(:,2:end,:)   = density(:,2:end,:) & density(:,1:end-1,:);
%     density(:,:,1:end-1) = density(:,:,1:end-1) & density(:,:,2:end);
%     density(:,:,2:end)   = density(:,:,2:end) & density(:,:,1:end-1);
%     
%     density(1:end-1,1:end-1,:) = density(1:end-1,1:end-1,:) & density(2:end,2:end,:);
%     density(1:end-1,2:end,:) = density(1:end-1,2:end,:) & density(2:end,1:end-1,:);
%     density(2:end,1:end-1,:) = density(2:end,1:end-1,:) & density(2:end,1:end-1,:);
%     
%     density(1:end-1,:,1:end-1) = density(1:end-1,:,1:end-1) & density(2:end,:,2:end);
%     density(1:end-1,:,2:end) = density(1:end-1,:,2:end) & density(2:end,:,1:end-1);
%     density(2:end,:,1:end-1) = density(2:end,:,1:end-1) & density(2:end,:,1:end-1);
%     
%     density(:,1:end-1,1:end-1) = density(:,1:end-1,1:end-1) & density(:,2:end,2:end);
%     density(:,1:end-1,2:end) = density(:,1:end-1,2:end) & density(:,2:end,1:end-1);
%     density(:,2:end,1:end-1) = density(:,2:end,1:end-1) & density(:,2:end,1:end-1);
% end

end
