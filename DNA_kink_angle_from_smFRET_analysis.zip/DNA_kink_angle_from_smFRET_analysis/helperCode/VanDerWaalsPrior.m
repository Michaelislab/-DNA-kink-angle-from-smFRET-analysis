function [ VdWprior ] = VanDerWaalsPrior( pdb, xax, yax, zax, varargin )
%VANDERWAALSPRIOR returns a Van der Waals prior
% The program returns a 3 dimensional mask for a rectangular grid defined
% by the axes xax, yax and zax with 0s where the corresponding points lie inside a
% protein loaded from a PDB file and 1s otherwise.
%
% calling syntax:
%   VdWprior = VanDerWaalsPrior( pdb, xax, yax, zax )
%   VdWprior = VanDerWaalsPrior( pdb, xax, yax, zax, rObj )
%
% input arguments:
%   pdb      structure as returnded by LoadAtomPositions or name of a pdb file
%   xgrd     xaxis, must be equally spaced
%   ygrd     yaxis, must be equally spaced
%   zgrd     zaxis, must be equally spaced
%   rObj     van der Waals radius of the object that is excluded from the
%            interior of the protein
%
% output arguments:
%   VdWprior    3 dimensional matrix that contains the prior, nor normalized
%
% changes log:
%   2007-12-05  start writing... [Adam Muschielok]
%   2007-??-??  ... finished [Adam Muschielok]
%   2008-04-24  arbitrary van der waals radius of the object to exclude is
%               now possible [Adam Muschielok]

% initialization
switch nargin
    case 4
        rObj = 1.20;  % VdW raidius of the object to exclude (in angstroem) to the radius of an hydrogen atom
    case 5
        rObj = varargin{1};
    otherwise
        VdWprior = [];
        return
end

% reshape axes to be row vectors
xax = reshape(xax, 1, []);
yax = reshape(yax, 1, []);
zax = reshape(zax, 1, []);


% check whether a pdb file structure is given or whether it's a file name
if ischar(pdb)
    % read the pdb file
    disp('loading pdb file...');
    pdb = LoadAtomPositions( pdb );
    disp('...done.');
end
pos = pdb.positions;
nam = pdb.names;
B = pdb.Bfactors;

% calculate VdW radii and add the VdW radius of an hydrogen atom to it
VdWradii = GetVdWradii( nam ) + rObj;
VdWradii2 = VdWradii.^2;

% check whether there were some unknown elements
if any(VdWradii < 0)
    error('unknown atom name in the PDB file');
end

% calculate squared distances in each direction from atoms for each axis
% point
xr2 = (ones(size(pos,1),1)*xax - pos(:,1)*ones(1,length(xax))).^2;
yr2 = (ones(size(pos,1),1)*yax - pos(:,2)*ones(1,length(yax))).^2;
zr2 = (ones(size(pos,1),1)*zax - pos(:,3)*ones(1,length(zax))).^2;

% calculate transformation from position to index
slpx = (length(xax)-1)/(xax(end)-xax(1));
slpy = (length(yax)-1)/(yax(end)-yax(1));
slpz = (length(zax)-1)/(zax(end)-zax(1));
ofsx = xax(1);
ofsy = yax(1);
ofsz = zax(1);

% prepare prior
VdWprior = ones(length(xax),length(yax),length(zax));

Nx = length(xax);
Nxy = length(xax)*length(yax);

progress = 0;   % progress in %

for n=1:size(pos,1)     % for each atom...
    % calculate partial axes (take only the points that are close enough to
    % the current atom)
    pxind = (max(ceil(1+slpx*(pos(n,1)-ofsx-VdWradii(n))),1):min(floor(1+slpx*(pos(n,1)-ofsx+VdWradii(n))),length(xax)));
    pyind = (max(ceil(1+slpy*(pos(n,2)-ofsy-VdWradii(n))),1):min(floor(1+slpy*(pos(n,2)-ofsy+VdWradii(n))),length(yax)));
    pzind = (max(ceil(1+slpz*(pos(n,3)-ofsz-VdWradii(n))),1):min(floor(1+slpz*(pos(n,3)-ofsz+VdWradii(n))),length(zax)));
    
    [Xi,Yi,Zi] = ndgrid(pxind,pyind,pzind); % make index matrices

    % find indeces of prior elements == 1
    I2 = find( VdWprior(pxind,pyind,pzind) == 1);
    
    % and calculate the squared distance of each grid point in the relevant
    % region to the atom
    r2 = xr2(n,Xi(I2)) + yr2(n,Yi(I2)) + zr2(n,Zi(I2));
    
    % set the prior
    I = find( r2<=VdWradii2(n) );
    
    VdWprior(Xi(I2(I))+Nx*(Yi(I2(I))-1)+Nxy*(Zi(I2(I))-1)) = 0;
    
end










