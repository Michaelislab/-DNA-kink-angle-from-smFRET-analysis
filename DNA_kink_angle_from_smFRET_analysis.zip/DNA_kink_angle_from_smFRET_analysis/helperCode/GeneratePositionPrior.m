function [axes, posprior] = GeneratePositionPrior( pdb, attpnt, attatomrad, diamdye, diamlink, lenlink, varargin )
%GENERATEPOSITIONPRIOR generates the position prior for a satellite dye used in the FRETnano-positioning system
% The satellite dye is modelled as a sphere attached to a flexible linker
% with a finite length and thickness. The linker is attached to the
% macromolecular complex at the attachment point. The position prior is
% constant at the points which can be reached by the attached satellite
% dye.
%
% function calling:
%   [axes, posprior] = GeneratePositionPrior( pdb, attpnt, attatomrad,
%                           diamdye, diamlink, lenlink )
%       calculates the position prior sampled at the grid specified by axes
%   [axes, posprior] = GeneratePositionPrior( pdb, attpnt, attatomrad,
%                           diamdye, diamlink, lenlink, skeldist )
%       the same as above, but the excluded volume is skeletonized before
%       postion prior calculation
%   [axes, posprior] = GeneratePositionPrior( pdb, attpnt, attatomrad,
%                           diamdye, diamlink, lenlink, skeldist, ax )
%       the same as above, but additionally use predefined axes
%
% input arguments:
%   pdb         structure as returnded by LoadAtomPositions or name of a pdb file (string)
%               if pdb is empty (i.e. []) then a solid sphere is returned
%   attpnt      point of attachment of the linker to the macromolecular
%               complex, vector of length 3 [x,y,z] with positions in angstroem 
%   attatomrad  radius of the atom of attachment, scalar
%   diamdye     diameter of the dye
%   diamlink    diameter of the linker in angstroem
%               vector of length N, if the linker consists of N floppy
%               chains with different diameter / length
%               NOTE that the linker starts at the attachment point and
%               ends at the CENTER of the sphere that is used to model the
%               dye
%   lenlink     length of the linker in angstroem
%               vector of length N, if the linker consists of N floppy
%               chains with different diameter / length
%   skeldist    skeletonizsation distance - the calculated excluded volume
%               is shrunk that distance at the borders
%   ax          axes, cell vector of three vectors containing the x, y and
%               z axis, i.e. ax = {[xmin, ..., xmax], [ymin, ..., ymax], [zmin, ..., zmax]}
%
% output arguments:
%   axes        axes that determine the position of the grid points the
%               position prior is calculated on; cell array of vectors
%   posprior    position prior, 3 dimensional matrix
%               size(posprior) =
%                ( length(axes{1}),length(axes{2}),length(axes{3}) )
%
% changes log:
%   2008-06-10  start writing... [Adam]
%   2008-06-13  first version running [Adam]
%   2011-05-16  axes can be given by the user [Adam]

axes = {};
skelDist = [];

switch nargin
    case 7      % skeletonize
        skelDist = varargin{1};     % set skeletonization distance
    case 8      % use predefined axes
        axes = varargin{2};         % set axes
    otherwise
        error('wrong number of parameters');
end

% maximum van der waals radius of an atom
vdwradmax = 2.5;

if isempty(skelDist)    % set default skeletonization distance if it was not specified by the user
    skelDist = 0.0;
end

if isempty(axes)      % set default grid spacing if it was not specified by user
    % calculate grid spacing, oversample the the smallest length:
    ovsmpl = 5;     % oversampling factor
    grdspc = min([min(diamdye),min(diamlink),min(lenlink)]) / ovsmpl;    % grid spacing
    % calculate the maximum length of the linker-dye construct
    maxlen = sum(lenlink) + diamdye/2 + vdwradmax;
    % calculate the axes (spanning the supporting points of the density)
    axe = -maxlen:grdspc:maxlen;
    axes = {axe+attpnt(1), axe+attpnt(2), axe+attpnt(3)};
end

% prepare coordinate matrices
[X,Y,Z] = ndgrid(axes{1},axes{2},axes{3});

% check whether a pdb structure should be used
if isempty(pdb)     % no pdb structure
    % calculate the position prior - it's just a solid sphere
    wbarh = waitbar(0,'calculating position prior');   % create waitbar
    disp('calculating position prior...');
    posprior = ( ( (X-attpnt(1)).^2 + (Y-attpnt(2)).^2 + (Z-attpnt(3)).^2 ) <=  sum(lenlink)^2 );
    disp('...done');
    close(wbarh);
else                % pdb structure provided in some form
    % check whether a pdb file structure is given or whether it's a file name
    if ischar(pdb)
        % read the pdb file
        disp('loading pdb file...');
        wbarh = waitbar(0,'loading pdb file');   % create waitbar
        pdb = LoadAtomPositions( pdb );
        disp('...done.');
        close(wbarh);
    end

    % ---- calculate the prior ----

    % -- calculate the prior for the first part of the linker
    % calculate the Van der Waals excluded volume for a object of the size of a single chain segment
    posprior = VanDerWaalsPrior( pdb, axes{1},axes{2},axes{3}, diamlink(1) / 2 );

    % skeletonize excluded volume if necessary
    if (skelDist ~= 0.0)
%        skelSteps = skelDist / (sqrt(2)*max(grdspc));     % number of skeletonization steps
        posprior = ~SkeletonizeDensity(~posprior, axes, skelDist);
%     else
%         skelSteps = 0;
    end
    
    % allow the volume that is occupied by the attached end of the linker
    % take into the account the finite radius of the atom of attachment

    ChainSegmentVdWprior = posprior | (( (X-attpnt(1)).^2 + (Y-attpnt(2)).^2 + (Z-attpnt(3)).^2 ) <= (1.1*(diamlink(1)/2+attatomrad))^2);
    % calculate the floppy chain prior

    posprior = posprior & FloppyChainPrior( ChainSegmentVdWprior, axes{1},axes{2},axes{3},attpnt,lenlink(1));

    % -- calculate the prior for the rest of the linker
    for i=2:length(lenlink)

        ChainSegmentVdWprior = VanDerWaalsPrior( pdb, axes{1},axes{2},axes{3}, diamlink(i) / 2 );
        if (skelDist ~= 0)
            ChainSegmentVdWprior = ~SkeletonizeDensity(~ChainSegmentVdWprior, axes, skelSteps);
        end
        % calculate the floppy chain prior for the next linker
        startpos = find((posprior & ChainSegmentVdWprior)>0);

        posprior = FloppyChainPrior( ChainSegmentVdWprior, axes{1},axes{2},axes{3}, startpos, ones(size(startpos))*lenlink(i));
    end

    % -- calculate the v.d.waals prior for the dye

    if (skelDist ~= 0)
        posprior = posprior & ~SkeletonizeDensity(~VanDerWaalsPrior( pdb, axes{1},axes{2},axes{3}, diamdye / 2 ), axes, skelDist);
    else
        posprior = posprior & VanDerWaalsPrior( pdb, axes{1},axes{2},axes{3}, diamdye / 2 );
    end

end
