function [ filename, pathname ] = uiiofile( identifier, mode, varargin )
%UIIOFILE Open standard dialog box for retrieving / saving files and keep default directories for later use
%   this command works similar to uigetfile and uiputfile, but keeps the
%   last directory used in memory and saves it to disk into the default
%   MATLAB user directory under the file name uiiofile.mat
%
% SYNTAX:
%   [ filename, pathname ] = uiiofile( identifier, mode )
%   [ filename, pathname ] = uiiofile( identifier, mode, defext )
%   [ filename, pathname ] = uiiofile( identifier, mode, defext, dlgname )
%
% INPUT ARGUMENTS:
%   identifier      string used for identification of the default loading
%                   and saving directories, must consist of alphanumeric
%                   characters
%   mode            mode, possible modes are:
%           'Load'                  opens a single file load dialog
%           'LoadMultiSelect'       opens a multiple file load dialog
%           'Save'                  opens a file save dialog
%   defext          default extension, string or cell array of strings
%   dlgname         dialog name
%
% OUTPUT ARGUMENTS:
%   filename        selected single file name as string or several file
%                   names in a cell array
%   pathname        path name as string
%   

% --- CHANGES LOG ---------------------------------------------------------
% 2009-12-02    code written and tested [Adam Muschielok]
% 2009-12-10    default directories are saved now into a file in the MATLAB
%               user directory [Adam Muschielok]
% -------------------------------------------------------------------------

%% definition of memory file on disk
pth = userpath;     % get default user path
if pth(end) == pathsep
    pth = pth(1:end-1);
end
if pth(end) ~= filesep
    pth = [pth, filesep];
end
memfilename = [pth, 'uiiofile.mat'];   % memory file

%% check input
switch nargin
    case 2
        dlgname = [];
        defext = '*.*';
    case 3
        dlgname = [];
        defext = varargin{1};
    case 4
        defext = varargin{1};
        dlgname = varargin{2};
    otherwise
        error('bad number of input arguments');
end
% check mode
if ~any(strcmpi(mode, {'load', 'loadmultiselect', 'save'}))
    error('unknown calling mode, should be either ''Load'', ''LoadMultiSelect'', or ''Save''');
else
    mode = lower(mode);
end
if isempty(dlgname)
    switch mode
        case 'load'
            dlgname = 'Load file...';
        case 'loadmultiselect'
            dlgname = 'Load files...';
        case 'save'
            dlgname = 'Save file...';
    end
end
if ~ischar(identifier)
    error('identifier must be a string');
elseif ~isstrprop(identifier, 'alphanum')
    error('identifier must consist of alphanumeric characters');
end
if ~ischar(mode)
    error('mode must be a string');
end
if isempty(defext)
    defext = '*.*';
elseif ~(ischar(defext) || iscell(defext))
    error('default extension must be a string or a cell array of strings');
end
if ~ischar(dlgname)
    error('dialog name must be a string');
end

%% generate global data
%glbdefdir = ['UIIOFILE_' identifier '_directory'];       % full identifier
%eval(['global ' glbdefdir]);       % generate global variable
%eval(['defdir = ' glbdefdir ';']);     % make a local copy with unique name
global UIIOFILE_directories
if isempty(UIIOFILE_directories)
    % load default directories from file if present
    try
        % load default directories from file
        UIIOFILE_directories = load(memfilename);
        defdir = UIIOFILE_directories.(identifier);
    catch ME
        % there was an error, start with empty default directories structure
        UIIOFILE_directories.(identifier) = [];
        defdir = [];
        warning(['could not read default directories from ''' memfilename '''']);
    end
else
    try
        defdir = UIIOFILE_directories.(identifier);
    catch ME
        defdir = [];
    end
end

%% load default directories if present
if isempty(defdir)  % very first run
    switch mode
        case {'load', 'loadmultiselect'}
            defdir.load = cd;       % use current directory to load
            defdir.save = [];
        case 'save'
            defdir.load = [];
            defdir.save = cd;       % use current directory to save
    end
else                % second or later run
    switch mode
        case {'load', 'loadmultiselect'}
            if isempty(defdir.load)     % if it's the first load command
                defdir.load = defdir.save;	% use default save directory
            end
        case 'save'
            if isempty(defdir.save)     % if it's the first save command
                defdir.save = defdir.load;	% use default load directory
            end
    end
end

%% select files
switch mode
    case 'load'
        [filename, pathname] = uigetfile(defext, dlgname, defdir.load);
    case 'loadmultiselect'
        [filename, pathname] = uigetfile(defext, dlgname, defdir.load, 'MultiSelect', 'on');        
    case 'save'
        [filename, pathname] = uiputfile(defext, dlgname, defdir.save);        
end

if isequal(filename,0) || isequal(pathname,0)
    % User selected Cancel
    return
end

% keep directory as default
switch mode
    case {'load', 'loadmultiselect'}
        defdir.load = pathname;
    case 'save'
        defdir.save = pathname;
end

UIIOFILE_directories.(identifier) = defdir;     % put local copy in global variable

try
    % save default directories into file
    if exist(memfilename, 'file')
        save(memfilename, '-struct', 'UIIOFILE_directories', identifier, '-append');
    else
        save(memfilename, '-struct', 'UIIOFILE_directories', identifier);
    end
catch ME
	warning(['could not write default directories to ''' memfilename '''']);
end
end
