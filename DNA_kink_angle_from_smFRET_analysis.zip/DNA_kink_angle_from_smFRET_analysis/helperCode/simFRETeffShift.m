
function meanFRET = simFRETeffShift(axesD, densityD, axesA, densityA, trajN, kD, Riso, depD, kRD, depA, kRA)

% all times are ns and all distances are in nm

%% Rotation Parameters

psi = @(dep) acos(sqrt(2.*sqrt(dep) + 0.25) - 0.5);

psiD =  psi(depD);
psiA =  psi(depA);

cPsiD = cos(psiD);
cPsiA = cos(psiA);

B = @(cPsi) -cPsi.^2.*(1+cPsi).^2 .* (log((1+cPsi)./2) + (1 - cPsi)./2)./ (2.*(1 - cPsi)) + (1-cPsi).*(6+8.*cPsi-cPsi.^2-12.*cPsi.^3-7.*cPsi.^4)./24;

DRotD = B(cPsiD) * kRD / (1 - depD); % rad^2/ns
DRotA = B(cPsiA) * kRA / (1 - depA); % rad^2/ns

%% translation Parameters

DTransD = 0.11; %0.11; % nm^2/ns
DTransA = 0.11; %0.11; % nm^2/ns

%% Positions
capsN = 6;

histD = capmat(densityD);
histA = capmat(densityA);

for i = 1:capsN
    histD = capmat(histD);
    histA = capmat(histA);
end

axesMinD = ([axesD{1}(1);axesD{2}(1);axesD{3}(1)] - repmat(capsN,3,1))/10 - 0.05; % shift by 0.5 A since boxes have edge length 1 A
axesMinA = ([axesA{1}(1);axesA{2}(1);axesA{3}(1)] - repmat(capsN,3,1))/10 - 0.05;

posD = zeros(3,trajN);
posA = zeros(3,trajN);

maxIndD = size(histD)';
maxIndA = size(histA)';

a = 0;

for trajInd = 1:trajN
    
    randIndD = ceil(rand(3,1) .* maxIndD);
    while ~histD(randIndD(1),randIndD(2),randIndD(3))
        randIndD = ceil(rand(3,1) .* maxIndD);
    end
    posD(:,trajInd) = randIndD + 10 .* axesMinD - rand(3,1);
    
    % test
    tempPosD = posD(:,trajInd)./10;
    histIndD = ceil(10.*(tempPosD - axesMinD));
    
    if ~histD(histIndD(1),histIndD(2),histIndD(3))
        a = a + 1;
    end
    
    randIndA = ceil(rand(3,1) .* maxIndA);
    while ~histA(randIndA(1),randIndA(2),randIndA(3))
        randIndA = ceil(rand(3,1) .* maxIndA);
    end
    posA(:,trajInd) = randIndA + 10 .* axesMinA - rand(3,1);
    
    % test
    tempPosA = posA(:,trajInd)/10;
    histIndA = ceil(10.*(tempPosA - axesMinA));
    
    if ~histA(histIndA(1),histIndA(2),histIndA(3))
        a = a + 1;
    end
end
if a > 0
    error('outside Position Prior')
end

posD = posD ./ 10;
posA = posA ./ 10;


%% Orientations
%% restricted Oris
% axes
[coeffD,~,latentD] = pca(posD');
[coeffA,~,latentA] = pca(posA');

[~,indMaxLatentD] = max(latentD);
[~,indMaxLatentA] = max(latentA);

axD = coeffD(:,indMaxLatentD);
axD = axD ./ norm(axD);
axA = coeffA(:,indMaxLatentA);
axA = axA ./ norm(axA);

% random angles from axis away
randPsiD = repmat(acos((1-cPsiD).*rand(1,trajN)+ cPsiD),3,1);
randPsiA = repmat(acos((1-cPsiA).*rand(1,trajN)+ cPsiA),3,1);

% rotation angle around axis2
randPhiD = repmat(2 .* pi .* rand(1,trajN),3,1);
randPhiA = repmat(2 .* pi .* rand(1,trajN),3,1);

% random ori's in cones with average axes ax's

kernelD = null(axD'); % axis orthogonal plane vectors
kernelA = null(axA'); % axis orthogonal plane vectors

oriD = sin(randPsiD) .* (cos(randPhiD) .* ...
    repmat(kernelD(:,1),1,trajN) + sin(randPhiD) .* repmat(kernelD(:,2),1,trajN)) ...
    + cos(randPsiD) .* repmat(axD,1,trajN);

oriA = sin(randPsiA) .* (cos(randPhiA) .* ...
    repmat(kernelA(:,1),1,trajN) + sin(randPhiA) .* repmat(kernelA(:,2),1,trajN)) ...
    + cos(randPsiA) .* repmat(axA,1,trajN);

%% Simulation Parameters

radiusD = (3*sum(sum(sum(histD)))/(4*pi)).^(1/3)/10;

radiusA = (3*sum(sum(sum(histA)))/(4*pi)).^(1/3)/10;

minTransTime = min([radiusD^2/(6*DTransD),radiusA^2/(6*DTransA)]);

minRotTime = min([psiD^2/(6*DRotD),psiA^2/(6*DRotA)]);

meanDist = norm(mean(posD,2) - mean(posA,2));

meanKT = kD * (Riso/meanDist)^6;

h = max(10^(-3),min([minTransTime,minRotTime,1/kD,1/meanKT]) / 100);

cTransD = sqrt(6*DTransD*h);
cTransA = sqrt(6*DTransA*h);

cRotD = sqrt(2*DRotD*h);
cRotA = sqrt(2*DRotA*h);

%% Simulation Arrays

kT = zeros(1,trajN);

kappaSq = kT;

photonTime = kT;

emissionBool = kT;

%% Simulation
for trajInd = 1:trajN
    
    stop = false;
    
    simStep = 1;
    
    while  ~stop % simulation if trajectories
        
        %% donor
        % position update
        tempPosD = posD(:,trajInd) + cTransD .* randn(3,1);
        
        histIndD = ceil(10.*(tempPosD - axesMinD));
        
        while ~histD(histIndD(1),histIndD(2),histIndD(3))
            tempPosD = posD(:,trajInd) + cTransD .* randn(3,1);
            histIndD = ceil(10.*(tempPosD - axesMinD));
        end
        
        posD(:,trajInd) = tempPosD;
        
        % orientation update
        tempOriD = oriD(:,trajInd) + cRotD .* randn(3,1);
        tempOriD = tempOriD ./ norm(tempOriD);
        
        while dot(tempOriD,axD) <= cPsiD
            tempOriD = oriD(:,trajInd) + cRotD .* randn(3,1);
            tempOriD = tempOriD ./ norm(tempOriD);
        end
        
        oriD(:,trajInd) = tempOriD;
        
        %% acceptor
        
        % position update
        tempPosA = posA(:,trajInd) + cTransA .* randn(3,1);
        
        histIndA = ceil(10.*(tempPosA - axesMinA));
        
        while ~histA(histIndA(1),histIndA(2),histIndA(3))
            tempPosA = posA(:,trajInd) + cTransA .* randn(3,1);
            histIndA = ceil(10.*(tempPosA - axesMinA));
        end
        
        posA(:,trajInd) = tempPosA;
        
        % orientation update
        tempOriA = oriA(:,trajInd) + cRotA .* randn(3,1);
        tempOriA = tempOriA ./ norm(tempOriA);
        
        while dot(tempOriA,axA) <= cPsiA
            tempOriA = oriA(:,trajInd) + cRotA .* randn(3,1);
            tempOriA = tempOriA ./ norm(tempOriA);
        end
        
        oriA(:,trajInd) = tempOriA;
        
        
        %% Poisson Processes
        normR = posD(:,trajInd)-posA(:,trajInd);
        
        D6 = (Riso^2/sum(normR.^2))^3;
        
        normR = normR ./ norm(normR);
        
        kappaSq(trajInd) = (oriD(:,trajInd)'*oriA(:,trajInd) - 3 * (normR'*oriD(:,trajInd)) * (normR'*oriA(:,trajInd)))^2;
        
        kT(trajInd) = kD * 3/2 * kappaSq(trajInd) * D6;
        
        if rand(1,1) < (kD + kT(trajInd))*h
            if rand(1,1) < kD/(kD + kT(trajInd))
                emissionBool(trajInd) = 1;
            end
            photonTime(trajInd) = simStep * h;
            stop = true;
        end
        
        simStep = simStep + 1;
        
    end
end

%% FRET efficiency
meanFRET = sum(emissionBool == 0) / length(emissionBool);


end

