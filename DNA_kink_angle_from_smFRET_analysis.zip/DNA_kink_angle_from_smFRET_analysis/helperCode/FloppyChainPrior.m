function FCprior = FloppyChainPrior( allowedpos, xax, yax, zax, stpt, len )
%FLOPPYCHAINPRIOR returns a flat prior for the position of the end of a floppy chain
% The returned prior is true for every voxel v that can be reached from the
% starting point by a line that connects neighboring voxels in between the
% starting point and the voxel v, and if the connecting line is not longer
% then len, the length of the chain. Each voxel has 26 neighbouring voxels
% on the cubic lattice.
%
% input arguments:
%   allowedpos  3dim logical matrix encoding the allowed (1) and forbidden (0)
%               voxels for the chain
%   xgrd        xaxis, must be equally spaced
%   ygrd        yaxis, must be equally spaced
%   zgrd        zaxis, must be equally spaced
%   stpt        starting point for the chain, vector [x,y,z], or a vector
%               of linear indeces for the matrix allowedpos;
%   len         length of the chain, scalar, or if stpt is a vector of
%               linear indeces, a vector with the remaining lengths at the
%               specified points
%
% output arguments:
%   FCprior     the floppy chain prior, a matrix of the same size like
%               allowedpos
%
% changes log:
%   2008-03-31  first version running (based on rectangular grid), but
%               there are problems with the metrics
%   2008-04-01  correct implementation of points lying outside of the box
%               defined by the axes [Adam]
%   2008-04-02  bug removed that selected all allowed voxels if the
%               starting point was inside the box [Adam]
%   2008-06-11  added option to start at multiple points at once
%               and removed bug that prevented reaching voxels by one chain
%               if already another chain could not reach them [Adam]

% make sure allowedpos is really a logical matrix
allowedpos = logical(allowedpos);

Nallowed = sum(sum(sum(allowedpos)));   % number of allowed positions

act = false(size(allowedpos));      % no active voxels yet

if ( (length(stpt) == 3) && length(len) == 1)       % one starting point specified
    multiStartingPointFlag = false;
    
    % check whether the starting point is inside or outside of the box
    dx = [xax(1),xax(end)]-stpt(1);   % direct distance contributions
    dy = [yax(1),yax(end)]-stpt(2);
    dz = [zax(1),zax(end)]-stpt(3);
    if ( (prod(dx) <= 0) && (prod(dy) <= 0) && (prod(dz) <= 0) )
        % starting point is inside
        reg = {find(xax<=stpt(1),1,'last'):find(xax>=stpt(1),1,'first'),find(yax<=stpt(2),1,'last'):find(yax>=stpt(2),1,'first'),find(zax<=stpt(3),1,'last'):find(zax>=stpt(3),1,'first')};
        % initialize active voxels
        act(reg{1},reg{2},reg{3}) = allowedpos(reg{1},reg{2},reg{3});
    else
        % starting point is outside
        switch -sum(sign(dx))
            case -2
                act(1,:,:) = allowedpos(1,:,:);
            case +2
                act(end,:,:) = allowedpos(end,:,:);
        end
        switch -sum(sign(dy))
            case -2
                act(:,1,:) = allowedpos(:,1,:);
            case +2
                act(:,end,:) = allowedpos(:,end,:);
        end
        switch -sum(sign(dz))
            case -2
                act(:,:,1) = allowedpos(:,:,1);
            case +2
                act(:,:,end) = allowedpos(:,:,end);
        end
    end

    if ~any(any(any(act)))    % if there are no valid starting points...
        FCprior = false(size(allowedpos));  % ... there are no allowed positions at all
        disp('WARNING: no allowed voxels in direct neighbourhood of the starting point!');
        disp('         floppy chain prior is empty!');
        return
    end
else    % there are multiple starting points given as linear indeces
    multiStartingPointFlag = true;
    act(stpt) = true;       % set the active points
end
    
% initialize calculated voxels
cal = false(size(allowedpos));
% initialize remaining length matrix
reml = zeros(size(allowedpos));
if ~multiStartingPointFlag
    [X,Y,Z] = ndgrid(xax,yax,zax);
    dist = sqrt((X-stpt(1)).^2+(Y-stpt(2)).^2+(Z-stpt(3)).^2);
    reml(act) = len - dist(act);
    clear X Y Z
    reml(act&(dist<0)) = 0;
else
    reml(act) = len;        % set the remaining lengths
end



% % calculate the step sizes from each point in the grid to its neighbours
% dx = abs(diff(xax));
% dy = abs(diff(yax));
% dz = abs(diff(zax));

% get the sizes of the grid
szx = size(allowedpos,1);
szy = size(allowedpos,2);
szz = size(allowedpos,3);

% build the chain
growingFlag = true;  % set the flag that indicates that the chain is growing
while growingFlag

    % update calculated mask:
    cal = cal | act;

    [dummys, dummyerr] = sprintf('%3.2f',100*sum(sum(sum(cal)))/Nallowed);
    %disp([dummys, ' %']);
    
%    tic
    % calculate new 
    for k=(-1:1)
        for j=(-1:1)
            for i=(-1:1)
                % find subsript indeces of the shifted active voxels
                [indX,indY,indZ] = ind2sub(size(act),find(act));
                shIndX = indX+i;
                shIndY = indY+j;
                shIndZ = indZ+k;
                % check for indices shifted outside of the bounds
                goodInd = ((shIndX>=1)&(shIndX<=szx)) & (shIndY>=1)&(shIndY<=szy) & (shIndZ>=1)&(shIndZ<=szz);
                shIndX = shIndX(goodInd);
                shIndY = shIndY(goodInd);
                shIndZ = shIndZ(goodInd);
                shInd = sub2ind(size(act),shIndX,shIndY,shIndZ);    % shifted linear indeces
                indX = indX(goodInd);
                indY = indY(goodInd);
                indZ = indZ(goodInd);
                
                % new remaining lengths
                nreml = reml(act);      % start from the active voxels...
                nreml = nreml(goodInd)- sqrt((i*(xax(shIndX)-xax(indX))).^2 + (j*(yax(shIndY)-yax(indY))).^2 + (k*(zax(shIndZ)-zax(indZ))).^2)';     % ...and subtract the distance to the neighbours
                % update old remaining lengths
                if ~isempty(nreml)
                    reml(shInd) = max(reml(shInd),nreml) .* allowedpos(shInd);
                end
                
            end
        end
    end
%    toc
    
	% calculate new active voxel masks
	act = act | cat(1,act(2:end,:,:),act(end,:,:)) | cat(1,act(1,:,:),act(1:(end-1),:,:));
	act = act | cat(2,act(:,2:end,:),act(:,end,:)) | cat(2,act(:,1,:),act(:,1:(end-1),:));
	act = act | cat(3,act(:,:,2:end),act(:,:,end)) | cat(3,act(:,:,1),act(:,:,1:(end-1)));
    act = act & (~cal) & allowedpos & (reml>0);
    
    growingFlag = any(any(any(act)));
end


% set all the voxels that can be reached by the chain to true, all
% remaining to false
FCprior = reml>0;