function [ infoStructure, attPointDon, attPointAcc] = LoadAtomPositions( fid, atomIDs)
%LOADATOMPOSTIONS Loads atom postions from a PDB (= Protein Data Bank) file
%
% input arguments:
%   pdbfilename     string with the path and name of the pdb file
% output arguments:
%   infoStructure structure with output information, contains following
%                 fields:
%      positions matrix of size (N,3) with the coordinates of the N atoms that
%                were read in. The coordinates are in Angstroems
%      names     atom name, character array of size (N,3)
%      Bfactors  B-factors (or temperature factors) of the atoms, vector of length N
%
% changes log:
%   2007-12-05  program running [Adam Muschielok]
%   2007-12-06  changed output into structure [Adam Muschielok]


i = 0;          % reset number of atoms

while true
    tline = fgets(fid);  % read text line
    if ~ischar(tline) || strcmp(tline(1:3), 'TER')   % file or model has ended
        break
    end
    
    if (length(tline)>=66 && strcmp(tline(1:6), 'ATOM  '))    % read the line if it starts with 'ATOM'
        i = i + 1;
        
        % Record Format
        %
        % COLUMNS      DATA TYPE        FIELD      DEFINITION
        % ------------------------------------------------------
        %  1 -  6      Record name      "ATOM    "
        %  7 - 11      Integer          serial     Atom serial number.
        % 13 - 16      Atom             name       Atom name.
        % 17           Character        altLoc     Alternate location indicator.
        % 18 - 20      Residue name     resName    Residue name.
        % 22           Character        chainID    Chain identifier.
        % 23 - 26      Integer          resSeq     Residue sequence number.
        % 27           AChar            iCode      Code for insertion of residues.
        % 31 - 38      Real(8.3)        x          Orthogonal coordinates for X in
        %                                          Angstroms
        % 39 - 46      Real(8.3)        y          Orthogonal coordinates for Y in
        %                                          Angstroms
        % 47 - 54      Real(8.3)        z          Orthogonal coordinates for Z in
        %                                          Angstroms
        % 55 - 60      Real(6.2)        occupancy  Occupancy.
        % 61 - 66      Real(6.2)        tempFactor Temperature factor.
        % 77 - 78      LString(2)       element    Element symbol, right-justified.
        % 79 - 80      LString(2)       charge     Charge on the atom.
        
        C = textscan(tline(13:16), '%4s');      % read atom name
        infoStructure.names(i,:) = C{1};
        C = textscan(tline(31:54), '%8.3f %8.3f %8.3f');      % read x,y & z coordinates
        infoStructure.positions(i,:) = cell2mat(C);
        C = textscan(tline(61:66), '%6.2f');      % read temperature factor
        infoStructure.Bfactors(i,1) = C{1};
        
        % attachment points of donor and acceptor
        atomID = tline(7:11);
        atomID = atomID(~isspace(atomID));
        if strcmp(atomID,num2str(atomIDs(1))) % donor    
            attPointDon = infoStructure.positions(i,:);    
        elseif strcmp(atomID,num2str(atomIDs(2))) % acceptor
            attPointAcc = infoStructure.positions(i,:);   
        end
    end
    
end
