%% Input Parameters

% [donor, acceptor] 
% atomIDs = [1164,565]; % DNA only 
% atomIDs = [2935,2336]; % F2+DNA
% atomIDs = [4522,3923]; % F1F2+DNA 

dyeDiamD = 12;
dyeDiamA = 12;
linkerDiam = 4.5;
linkerLengthD = 13;
linkerLengthA = 13;
skelDist = 2;

%%

addpath('./helperCode');

%% Load data

[filename, pathname] = uiiofile('PDBimport','Load','*.pdb','Load pdb file');
if isequal(filename,0) || isequal(pathname,0)
    % User selected Cancel
    return
else
    pdbFilename = [pathname, filename];
end

% check validity of the file
fid = fopen(pdbFilename, 'r')  % open file in read mode
pdbString = fscanf(fid,'%c');
numModels = length(strfind(pdbString,'MODEL'));
fclose(fid)  

fid = fopen(pdbFilename, 'r')  % open file in read mode

tic

priors = cell(1,numModels);

for modelInd = 1:numModels
  
%% Prior Structure
[pdbModelStructure, attPointDon, attPointAcc] = LoadAtomPositions( fid, atomIDs );

attAtomRadius = GetVdWradii({'C'});

[axesDon, densityDon] = GeneratePositionPrior(pdbModelStructure, attPointDon, attAtomRadius, dyeDiamD, linkerDiam, linkerLengthD, skelDist);
[axesAcc, densityAcc] = GeneratePositionPrior(pdbModelStructure, attPointAcc, attAtomRadius, dyeDiamA, linkerDiam, linkerLengthA, skelDist);

priors{modelInd} = {axesDon, axesAcc, densityDon, densityAcc}; 

modelInd

end

toc

fclose(fid)    % close file

[file,path] = uiputfile('*.mat');
if isequal(file,0) || isequal(path,0)
    return
else
    save([path,filesep,file],'priors')
end
