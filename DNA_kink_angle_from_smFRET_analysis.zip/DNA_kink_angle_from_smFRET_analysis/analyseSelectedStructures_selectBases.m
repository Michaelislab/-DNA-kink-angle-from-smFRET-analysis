%% This script does the same as analyseSelectedStructures.m (version 2018_08_28), 
% with the only difference that the user can specify which DNA residues 
% contribute to the two axes

%%

addpath('./helperCode');

clear


% specify axes: always count from 5' end, so that Start is always smaller
% as End
ax5Start1 = 1; % first residue of strand 1 of the 5'stem
ax5End1 = 10;   % last residue of strand 1 of the 5'stem
ax5Start2 = 17; % first residue of strand 2 of the 5'stem
ax5End2 = 26;   % last residue of strand 2 of the 5'stem

ax3Start1 = 27; % first residue of strand 1 of the 3'stem
ax3End1 = 41;   % last residue of strand 1 of the 3'stem
ax3Start2 = 48; % first residue of strand 2 of the 3'stem
ax3End2 = 62;   % last residue of strand 2 of the 3'stem



%%

[filename, pathname] = uiiofile('PDBimport','Load','*.pdb','Load pdb file');
if isequal(filename,0) || isequal(pathname,0)
    % User selected Cancel
    return
else
    pdbFilename = [pathname, filename];
end

FID = fopen([pathname,filesep,filename],'r');
pdbString = fscanf(FID,'%c');
numModels = length(strfind(pdbString,'MODEL'))

fclose(FID);

FID = fopen([pathname,filesep,filename],'r');

modelInd = 1;

dnaAxes = [];
dnaDir = [];
fixedDnaAxes = [];
fixedDnaDir = [];
phiDnaAxes = [];


while modelInd <= numModels
    atomPos = [];
    fixedAtomPos = [];
    dirPos = [];
    
    while true
        tline = fgets(FID);  % read text line
        if ~ischar(tline) || strcmp(tline(1:3), 'TER')   % file or model has ended
            break
        end
        
        if (length(tline)>=66) && strcmp(tline(1:6), 'ATOM  ') && (strcmp(tline(18:20), 'ADE') || strcmp(tline(18:20), 'GUA') || strcmp(tline(18:20), 'CYT') || strcmp(tline(18:20), 'THY'))
            % get DNA positions
            if  ((str2num(tline(23:26)) >= ax5Start1) && (str2num(tline(23:26)) <= ax5End1))  ||  ((str2num(tline(23:26)) >= ax5Start2) && (str2num(tline(23:26)) <= ax5End2)) 
                i = i + 1;
%                 str2num(tline(23:26))
                % Record Format
                %
                % COLUMNS      DATA TYPE        FIELD      DEFINITION
                % ------------------------------------------------------
                %  1 -  6      Record name      "ATOM    "
                %  7 - 11      Integer          serial     Atom serial number.
                % 13 - 16      Atom             name       Atom name.
                % 17           Character        altLoc     Alternate location indicator.
                % 18 - 20      Residue name     resName    Residue name.
                % 22           Character        chainID    Chain identifier.
                % 23 - 26      Integer          resSeq     Residue sequence number.
                % 27           AChar            iCode      Code for insertion of residues.
                % 31 - 38      Real(8.3)        x          Orthogonal coordinates for X in
                %                                          Angstroms
                % 39 - 46      Real(8.3)        y          Orthogonal coordinates for Y in
                %                                          Angstroms
                % 47 - 54      Real(8.3)        z          Orthogonal coordinates for Z in
                %                                          Angstroms
                % 55 - 60      Real(6.2)        occupancy  Occupancy.
                % 61 - 66      Real(6.2)        tempFactor Temperature factor.
                % 77 - 78      LString(2)       element    Element symbol, right-justified.
                % 79 - 80      LString(2)       charge     Charge on the atom.
                
                C = textscan(tline(31:54), '%8.3f %8.3f %8.3f');      % read x,y & z coordinates
                atomPos = [atomPos;cell2mat(C)];
            elseif ((str2num(tline(23:26)) >= ax3Start1) && (str2num(tline(23:26)) <= ax3End1))  ||  ((str2num(tline(23:26)) >= ax3Start2) && (str2num(tline(23:26)) <= ax3End2)) 
                C = textscan(tline(31:54), '%8.3f %8.3f %8.3f');      % read x,y & z coordinates
                fixedAtomPos = [fixedAtomPos;cell2mat(C)];
            end
            
            if (strcmp(tline(14), 'P')) && ((str2num(tline(23:26)) == 2) || (str2num(tline(23:26)) == 12) || (str2num(tline(23:26)) == 28) || (str2num(tline(23:26)) == 38))
                C = textscan(tline(31:54), '%8.3f %8.3f %8.3f');
                dirPos = [dirPos;cell2mat(C)];
            end
                       
        end
        
    end
    %% PCAs
    [coeff,~,latent] = pca(atomPos);
    [~,vecInd] = max(latent);
    dnaAxes = [dnaAxes,coeff(:,vecInd)];
    
    [coeff,~,latent] = pca(fixedAtomPos);
    [~,vecInd] = max(latent);
    fixedDnaAxes = [fixedDnaAxes,coeff(:,vecInd)];
    
    %% Directions
    dnaDir = [dnaDir;(dirPos(2,:)-dirPos(1,:))./norm(dirPos(2,:)-dirPos(1,:))];
    fixedDnaDir = [fixedDnaDir;(dirPos(4,:)-dirPos(3,:))./norm(dirPos(4,:)-dirPos(3,:))];
        
    modelInd = modelInd + 1
    
end

fclose(FID);

%% theta

% Direction correction
sum((acos(sum(dnaAxes.*dnaDir',1))>pi/4))
dnaAxes(:,(acos(sum(dnaAxes.*dnaDir',1))>pi/4)) = -dnaAxes(:,(acos(sum(dnaAxes.*dnaDir',1))>pi/4));
sum((acos(sum(fixedDnaAxes.*fixedDnaDir',1))>pi/4))
fixedDnaAxes(:,(acos(sum(fixedDnaAxes.*fixedDnaDir',1))>pi/4)) = -fixedDnaAxes(:,(acos(sum(fixedDnaAxes.*fixedDnaDir',1))>pi/4));

acos(sum(dnaAxes.*dnaDir',1));
acos(sum(fixedDnaAxes.*fixedDnaDir',1));

figure
cmap = hsv(10);
hold on
plot3([0,fixedDnaAxes(1)],[0,fixedDnaAxes(2)],[0,fixedDnaAxes(3)],'r')
hold on
scatter3(dnaAxes(1,:),dnaAxes(2,:),dnaAxes(3,:),[],'k')

xlim([-1,1])
ylim([-1,1])
zlim([-1,1])

%%

cosTheta = sum(fixedDnaAxes.*dnaAxes,1);

theta = acos(cosTheta);

%% expectations

numBins = 10;

%% mean ring
figure
[h,bins] = hist(theta,numBins);

binWidth = bins(2) - bins(1);

corrH = h ./ abs(cos(bins-binWidth)-cos(bins+binWidth));

corrH = corrH./sum(corrH);

bar(bins./pi.*180,corrH)

meanRingTheta = sum(corrH.*bins)./sum(corrH)./pi.*180 

stDRingTheta = sqrt(sum(corrH.*((bins./pi.*180-meanRingTheta).^2)))

xlim([0,180])

meanDnaAxes = mean(dnaAxes,2)
meanDnaAxes = meanDnaAxes./norm(meanDnaAxes);

meanFixedDnaAxes = mean(fixedDnaAxes,2);
meanFixedDnaAxes = meanFixedDnaAxes ./ norm(meanFixedDnaAxes);


%% mean (single) orientation
meanOriTheta = acos(sum(meanDnaAxes.*meanFixedDnaAxes))./pi*180

% angle of dna axes to mean of dna axes
angleToMeanDnaAxes = acos(sum(dnaAxes.*repmat(meanDnaAxes,1,size(dnaAxes,2),1)));

[h,bins] = hist(angleToMeanDnaAxes,numBins);

binWidth = bins(2) - bins(1);

corrH = h ./ abs(cos(bins-binWidth)-cos(bins+binWidth));

corrH = corrH./sum(corrH);

% bar(bins./pi.*180,corrH)

xlim([0,180])

stDOriTheta = sqrt(sum(corrH.*((bins./pi.*180).^2)))

figure
plot3([0,meanFixedDnaAxes(1)],[0,meanFixedDnaAxes(2)],[0,meanFixedDnaAxes(3)],'k')
hold on
scatter3(dnaAxes(1,:),dnaAxes(2,:),dnaAxes(3,:),[],'b')
plot3([0,meanDnaAxes(1)],[0,meanDnaAxes(2)],[0,meanDnaAxes(3)],'r')


