%% Input Parameters

expData = 0.86; 
sigma = 0.05;

%%

addpath('./helperCode');

%%

[filename, pathname] = uiiofile('PDBimport','Load','*.mat','Load FRET efficiencies');
if isequal(filename,0) || isequal(pathname,0)
    % User selected Cancel
    return
else
    load([pathname, filename]);
end

[filename, pathname] = uiiofile('PDBimport','Load','*.pdb','Load pdb file');
if isequal(filename,0) || isequal(pathname,0)
    % User selected Cancel
    return
else
    pdbFilename = [pathname, filename];
end

fileID1 = fopen([pathname,filesep,filename],'r');
pdbString = fscanf(fileID1,'%c');
numModels = length(strfind(pdbString,'MODEL'))

minVal = abs(repmat(expData,numModels,1) - meanFRETeff');

[values,sortInd] = sort(minVal);

numMinModels = find(values<sigma,1,'last')

startInd = strfind(pdbString,'MODEL');

stopInd = strfind(pdbString,'ENDMDL');

plot(values)
hold on
plot(1:numMinModels,values(1:numMinModels),'r')

modelString = [];

for modelInd = 1:numMinModels
    
    modelString = [modelString, pdbString(startInd(sortInd(modelInd)):stopInd(sortInd(modelInd))+6)];
    
end

[file,path] = uiputfile('*.pdb');
if isequal(file,0) || isequal(path,0)
    return
else
    fileID2 = fopen([path,filesep,file],'w');
    fprintf(fileID2,'%s',modelString);
end

fclose(fileID2);
fclose(fileID1);



